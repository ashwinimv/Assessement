import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-addtask',
  templateUrl: './addtask.component.html',
  styleUrls: ['./addtask.component.css']
})
export class AddtaskComponent implements OnInit {
 

  constructor(private router:Router) { }
   users :any=[];
  postData(addTask:NgForm){
    console.log(addTask.value);
    this.users.push(addTask.value);
    this.router.navigateByUrl('/viewtask');
    addTask.reset();
    console.log(this.users);
  }

  ngOnInit() {
  }

}
